import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:guide_me/mapbox_shim.dart' as mb;
import 'package:guide_me/mapbox_shim.dart';
import 'package:geolocator/geolocator.dart';

/// MapLogicHandler - uses a Ticker (60fps) to smoothly animate the user marker and camera.
/// It estimates velocity from incoming GPS samples and advances the displayed position
/// each tick. New GPS samples adjust the estimated velocity (low-pass) and gently pull
/// the displayed position towards the GPS to avoid drift.
class MapLogicHandler {
  VoidCallback? onUpdate;
  TickerProvider? tickerProvider;

  mb.MapboxMapController? controller;
  mb.Symbol? _userSymbol;

  // GPS tracking state
  Position? _lastGpsPosition;
  DateTime? _lastGpsTime;

  // Displayed (animated) position in lat/lon degrees
  LatLng? _displayPos;

  // --- Holt's double exponential smoothing (level + trend) for smooth cursor movement ---
  // We maintain smoothing separately in north (lat) and east (lon) directions in meters.
  double _lastGpsIntervalMs = 1000.0; // fallback expected sample interval in ms

  // origin reference for meter conversions (set on first sample)
  double? _originLat;
  double? _originLon;
  double _meanLatRadForConv = 0.0;

  // smoothing state (meters)
  double? _Lx; // level east (meters)
  double? _Tx; // trend east (meters per sample interval)
  double? _Ly; // level north (meters)
  double? _Ty; // trend north (meters per sample interval)

  // smoothing parameters (tunable)
  double _holtAlpha = 0.6; // level smoothing (0..1), higher -> more responsive
  double _holtBeta = 0.4;  // trend smoothing (0..1), higher -> faster trend updates


  // Velocity in meters per second: east (lon), north (lat)
  double _velEast = 0.0;
  double _velNorth = 0.0;

  // Ticker for smooth updates (~60fps)
  Ticker? _ticker;
  Duration _lastTick = Duration.zero;

  StreamSubscription<Position>? _posSub;

  MapLogicHandler({this.onUpdate, this.tickerProvider});

  Future<void> onMapCreated(mb.MapboxMapController ctrl) async {
    controller = ctrl;
    // start ticker for smooth animation if tickerProvider provided
    try {
      if (tickerProvider != null) {
        _ticker = tickerProvider!.createTicker(_onTick);
        _lastTick = Duration.zero;
        _ticker!.start();
      }
    } catch (e) {}
    _initLocationListening();
  }

  Future<void> dispose() async {
    await _posSub?.cancel();
    _ticker?.stop();
    _ticker?.dispose();
    _ticker = null;
  }

  Future<void> _initLocationListening() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return;
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        return;
      }

      // get initial position synchronously
      try {
        final p = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
        _onNewGps(p);
      } catch (e) {}

      // subscribe to stream - request frequent updates (distanceFilter small)
      _posSub = Geolocator.getPositionStream(
        locationSettings: const LocationSettings(accuracy: LocationAccuracy.best, distanceFilter: 1),
      ).listen((pos) {
        _onNewGps(pos);
      });
    } catch (e) {}
  }

  // Called on each incoming GPS sample
  void _onNewGps(Position pos) {
    final now = DateTime.now();

    // convert to lat/lon degrees
    final double lat = pos.latitude;
    final double lon = pos.longitude;

    // initialize origin for meter conversions on first sample
    if (_originLat == null || _originLon == null) {
      _originLat = lat;
      _originLon = lon;
      _meanLatRadForConv = _originLat! * (math.pi / 180.0);
    }

    // convert degrees to meters relative to origin
    final double metersPerDegLat = 111320.0;
    final double metersPerDegLon = 111320.0 * math.cos(_meanLatRadForConv);
    final double measX = (lon - _originLon!) * metersPerDegLon; // east
    final double measY = (lat - _originLat!) * metersPerDegLat; // north

    if (_lastGpsTime == null || _Lx == null || _Ly == null) {
      // first sample: initialize levels and trends
      _Lx = measX;
      _Ly = measY;
      _Tx = 0.0;
      _Ty = 0.0;
      _displayPos = LatLng(lat, lon);
      _lastGpsTime = now;
      _lastGpsIntervalMs = 1000.0;
      // create symbol if needed and center camera (preserve original behaviour)
      try {
        if (controller != null && _userSymbol == null) {
          controller!.addSymbol(SymbolOptions(geometry: _displayPos!, data: {'asset': 'assets/icons/marker.png'})).then((sym) {
            _userSymbol = sym;
            try { controller!.moveCameraImmediate(_displayPos!, 17.5); } catch (e) {}
            onUpdate?.call();
          });
        } else {
          try { controller?.moveCameraImmediate(_displayPos!, 17.5); } catch (e) {}
          onUpdate?.call();
        }
      } catch (e) {}
      _lastGpsPosition = pos;
      return;
    }

    // compute sample interval in ms and seconds
    final prevTime = _lastGpsTime!;
    final sampleMs = now.difference(prevTime).inMilliseconds.toDouble().clamp(10.0, 10000.0);
    _lastGpsIntervalMs = sampleMs;
    final double dtSamples = sampleMs / 1000.0;

    // Holt's linear trend update (discrete per-sample update)
    // Update level and trend separately for east (x) and north (y).
    final double Lx_prev = _Lx!;
    final double Ly_prev = _Ly!;
    final double Tx_prev = _Tx ?? 0.0;
    final double Ty_prev = _Ty ?? 0.0;

    _Lx = _holtAlpha * measX + (1.0 - _holtAlpha) * (Lx_prev + Tx_prev);
    _Tx = _holtBeta * (_Lx! - Lx_prev) + (1.0 - _holtBeta) * Tx_prev;

    _Ly = _holtAlpha * measY + (1.0 - _holtAlpha) * (Ly_prev + Ty_prev);
    _Ty = _holtBeta * (_Ly! - Ly_prev) + (1.0 - _holtBeta) * Ty_prev;

    _lastGpsTime = now;
    _lastGpsPosition = pos;

    // Ensure displayPos exists and will be smoothly interpolated in _onTick
    if (_displayPos == null) {
      final double dispLat = _originLat! + (_Ly! / metersPerDegLat);
      final double dispLon = _originLon! + (_Lx! / metersPerDegLon);
      _displayPos = LatLng(dispLat, dispLon);
    }
  }

  void _onTick(Duration elapsed) {
    // Simple guard
    if (_displayPos == null) return;

    // compute elapsed since last GPS sample
    final now = DateTime.now();
    double elapsedSinceSampleMs = (_lastGpsTime != null) ? now.difference(_lastGpsTime!).inMilliseconds.toDouble() : _lastGpsIntervalMs;
    // clamp to [0, sampleInterval]
    final double t = (_lastGpsIntervalMs > 0) ? (elapsedSinceSampleMs / _lastGpsIntervalMs) : 1.0;
    final double s = t.clamp(0.0, 1.0);

    // forecast using Holt's method: forecast = L + h * T, where h = fractional samples since last update
    final double h = s; // fraction of the sample interval
    // meters per degree constants (use origin)
    final double metersPerDegLat = 111320.0;
    final double metersPerDegLon = 111320.0 * math.cos(_meanLatRadForConv);

    final double forecastX = (_Lx ?? 0.0) + h * (_Tx ?? 0.0);
    final double forecastY = (_Ly ?? 0.0) + h * (_Ty ?? 0.0);

    // convert forecast meters back to lat/lon
    final double newLat = _originLat! + (forecastY / metersPerDegLat);
    final double newLon = _originLon! + (forecastX / metersPerDegLon);
    _displayPos = LatLng(newLat, newLon);

    // Update symbol and camera immediately using Mapbox shim
    try {
      if (_userSymbol != null && controller != null && _displayPos != null) {
        controller!.updateSymbolImmediate(_userSymbol!, _displayPos!);
        controller!.moveCameraImmediate(_displayPos!, 17.5);
      }
    } catch (e) {}

    // notify UI if necessary
    try { onUpdate?.call(); } catch (e) {}
  }

  double _distanceMeters(double lat1, double lon1, double lat2, double lon2) {
    final double R = 6371000.0;
    final double a1 = lat1 * (math.pi/180.0);
    final double a2 = lat2 * (math.pi/180.0);
    final double dLat = (lat2 - lat1) * (math.pi/180.0);
    final double dLon = (lon2 - lon1) * (math.pi/180.0);
    final double hav = math.sin(dLat/2)*math.sin(dLat/2) + math.cos(a1)*math.cos(a2)*math.sin(dLon/2)*math.sin(dLon/2);
    final double c = 2 * math.atan2(math.sqrt(hav), math.sqrt(1-hav));
    return R * c;
  }

  double _haversineDistance(double lat1, double lon1, double lat2, double lon2) {
    return _distanceMeters(lat1, lon1, lat2, lon2);
  }

  /// If some other part of the app wants to move camera to a previously set target
  Future<void> moveToTarget({double zoom = 16}) async {
    if (controller == null || _lastGpsPosition == null) return;
    await controller!.animateCamera(mb.CameraPosition(target: LatLng(_lastGpsPosition!.latitude, _lastGpsPosition!.longitude), zoom: zoom));
  }

  /// Backwards-compatible stub for legacy callers that expect a speedometer widget.
  /// Returns an empty sized box — override later if you need a real widget.
  Widget buildSpeedometer() {
    return const SizedBox.shrink();
  }
}
